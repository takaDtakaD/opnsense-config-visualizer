# OPNsense Config Visualizer

A single-file tool that reads an OPNsense `config.xml` and shows **which traffic is allowed and which is blocked**. No build step, no dependencies, fully offline.

[日本語](#日本語) | [English](#english)

![screenshot](docs/screenshot.png)

---

## 日本語

OPNsense の `config.xml`（System → Configuration → Backups でダウンロードしたもの）をブラウザにドロップすると、**どの通信が許可され、どれが拒否されるか**を中心に整理して表示します。ビルド不要、依存なし、オフラインで動作します。UI は右上のボタンで日本語と英語を切り替えられます。

### 特徴

- **通信可否マトリクス** — 送信元インターフェース × 送信先（各セグメント / This Firewall / インターネット）で、許可・拒否を一覧表示。セルをクリックすると一致したルールを表示
- **通信の判定テスト** — 送信元 IF・送信先・プロトコル・ポートを指定して、実際にどのルールで確定するかを確認
- **構成図** — WAN を上流、LAN / OPT を下流に置いた SVG。各ノードに pass / block の件数
- **ファイアウォールルール一覧** — 評価順に並べ、インターフェースごとのタブと検索。無効ルールは打ち消し線
- **気になるところ（簡易チェック）** — WAN の全許可、説明のないルール、NAT が Automatic で攻撃セグメントも NAT される、DHCP の二重配布など
- インターフェース、NAT（送信 NAT / ポートフォワード）、エイリアス、DHCP、ゲートウェイ、VLAN の一覧

### 使い方

1. `index.html` をブラウザで開く
2. `config.xml` をドロップ（またはクリックして選択）
3. 内容を確認。`Ctrl+P` で PDF にできます

`examples/sample-config.xml` で動作を試せます。ファイルはブラウザ内だけで処理され、外部に送信されません。

### 判定ロジック

pf / OPNsense の挙動に寄せた簡易シミュレーションです。

1. floating ルールを先に、そのあと送信元インターフェースのルールを上から評価
2. 最初に一致したルールで確定（quick）
3. 一致がなければ、そのインターフェースの既定拒否
4. 一致条件は、プロトコル / 送信元アドレス / 送信先アドレス / 送信先ポート
5. インターネット向けは、あわせて送信 NAT の有無も判定（NAT がなければ到達不可として表示）

### 制限

- IPv4 のみ判定します（IPv6 のルールは評価対象外）
- ルールの `direction out` と floating の out 方向は評価しません
- NAT リフレクション、ポートフォワード経由の到達性、ポリシールーティング（ゲートウェイ指定）は判定に含みません
- 表示は設定ファイルの静的な解析結果です。実機の `pfctl -sr` の出力とは差異が出る場合があります

---

## English

Drop an OPNsense `config.xml` (downloaded from System → Configuration → Backups) into the browser and it lays out **what is allowed and what is blocked**. No build step, no dependencies, no network access. Switch between Japanese and English with the buttons in the top right.

![screenshot (English)](docs/screenshot-en.png)

### Features

- **Reachability matrix** — sources (interfaces) × destinations (each segment / This Firewall / Internet), showing allow or block. Click a cell to see the rule that matched.
- **Policy tester** — pick a source interface, destination, protocol and port to see which rule decides the outcome.
- **Topology** — an SVG with WAN upstream and LAN / OPT downstream, with pass / block counts per node.
- **Firewall rules** — in evaluation order, with per-interface tabs and a search box. Disabled rules are struck through.
- **Things to check** — quick heuristics: allow-any rules on WAN, rules without a description, Automatic NAT that would also NAT a detonation segment, DHCP enabled on several interfaces, and so on.
- Interface, NAT (outbound and port forwards), aliases, DHCP, gateways and VLAN tables.

### Usage

1. Open `index.html` in a browser.
2. Drop your `config.xml` (or click to choose a file).
3. Review the report. Use `Ctrl+P` to export a PDF.

`examples/sample-config.xml` lets you try it without a real backup. The file is parsed in the browser and never leaves the machine.

### How the verdict is decided

A simplified simulation of pf / OPNsense behaviour:

1. Floating rules are evaluated first, then the rules of the source interface from the top.
2. The first match wins (quick).
3. If nothing matches, the interface default deny applies.
4. Matching considers protocol, source address, destination address and destination port.
5. For the Internet column, outbound NAT is checked too; without NAT the traffic is shown as unreachable.

### Limitations

- IPv4 only; IPv6 rules are not evaluated.
- Rules with `direction out` and floating rules in the out direction are not evaluated.
- NAT reflection, reachability through port forwards and policy routing (gateway on a rule) are not modelled.
- Results come from static analysis of the configuration and may differ from `pfctl -sr` on the live firewall.

## License

MIT
